using UnityEngine;
using UnityEngine.InputSystem;

public class MouseLook : MonoBehaviour
{
    [Header("Configuraci�n")]
    [SerializeField] private float sensibilidad = 0.1f;

    [Header("L�mite de visi�n vertical")]
    [Tooltip("M�ximo de grados que puede mirar hacia arriba o abajo desde la posici�n inicial.")]
    [SerializeField] private float limiteVertical = 60f;

    private float rotacionVertical;
    private float rotacionInicialX;

    private void Start()
    {
        GuardarRotacionInicial();
    }

    private void Update()
    {
        RotarCamara();
    }

    private void GuardarRotacionInicial()
    {
        rotacionInicialX = transform.localEulerAngles.x;

        if (rotacionInicialX > 180f)
            rotacionInicialX -= 360f;

        rotacionVertical = 0f;
    }

    private void RotarCamara()
    {
        if (Mouse.current == null)
            return;

        Vector2 movimientoMouse = Mouse.current.delta.ReadValue();

        // Acumulamos poco a poco el movimiento vertical
        rotacionVertical -= movimientoMouse.y * sensibilidad;

        // Limitamos �nicamente cuando realmente alcanzamos el l�mite
        rotacionVertical = Mathf.Clamp(
            rotacionVertical,
            -limiteVertical,
            limiteVertical
        );

        // Aplicamos la rotaci�n inicial + el movimiento acumulado
        transform.localRotation = Quaternion.Euler(
            rotacionInicialX + rotacionVertical,
            0f,
            0f
        );
    }

    public void RestaurarRotacionInicial()
    {
        rotacionVertical = 0f;

        transform.localRotation = Quaternion.Euler(
            rotacionInicialX,
            0f,
            0f
        );
    }
}